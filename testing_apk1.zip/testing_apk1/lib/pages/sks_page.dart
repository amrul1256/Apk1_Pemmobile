import 'package:flutter/material.dart';

class SKSPage extends StatelessWidget {
  const SKSPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Data mata kuliah
    final List<Map<String, dynamic>> mataKuliah = [
      {'semester': '1', 'matkul': 'Pengantar Teknologi Informasi', 'sks': 3},
      {'semester': '1', 'matkul': 'Matematika Diskrit', 'sks': 3},
      {'semester': '2', 'matkul': 'Algoritma dan Pemrograman', 'sks': 3},
      {'semester': '2', 'matkul': 'Struktur Data', 'sks': 3},
      {'semester': '3', 'matkul': 'Basis Data', 'sks': 3},
      {'semester': '3', 'matkul': 'Sistem Operasi', 'sks': 3},
      {'semester': '4', 'matkul': 'Jaringan Komputer', 'sks': 3},
      {'semester': '4', 'matkul': 'Pemrograman Web', 'sks': 3},
      {'semester': '5', 'matkul': 'Pemrograman Mobile', 'sks': 3},
      {'semester': '5', 'matkul': 'Rekayasa Perangkat Lunak', 'sks': 3},
      {'semester': '6', 'matkul': 'Kecerdasan Buatan', 'sks': 3},
      {'semester': '6', 'matkul': 'Keamanan Informasi', 'sks': 3},
      {'semester': '7', 'matkul': 'Manajemen Proyek TI', 'sks': 3},
      {'semester': '7', 'matkul': 'Etika Profesi', 'sks': 2},
    ];

    // Hitung total SKS
    int totalSKS =
        mataKuliah.fold(0, (sum, item) => sum + (item['sks'] as int));

    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail SKS"),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Header image
            Image.network(
              'https://cdn-icons-png.flaticon.com/512/3135/3135786.png',
              height: 90,
            ),
            const SizedBox(height: 12),

            const Text(
              "Rincian SKS yang Telah Diambil",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              "Berikut daftar mata kuliah yang telah diambil",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 20),

            // === TABEL ===
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    headingRowColor:
                        WidgetStateProperty.all(Colors.blueAccent.withOpacity(0.2)),
                    columnSpacing: 30,
                    dataRowHeight: 60,
                    horizontalMargin: 20,
                    dividerThickness: 1,
                    border: TableBorder.all(color: Colors.grey.shade300, width: 1),
                    columns: const [
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("Semester",
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("Mata Kuliah",
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("SKS",
                              style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                    rows: List.generate(mataKuliah.length, (index) {
                      final data = mataKuliah[index];
                      return DataRow(
                        color: WidgetStateProperty.all(
                          index.isEven
                              ? Colors.white
                              : Colors.blueAccent.withOpacity(0.05),
                        ),
                        cells: [
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['semester']!),
                          )),
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['matkul']!),
                          )),
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['sks'].toString()),
                          )),
                        ],
                      );
                    }),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // === Total SKS ===
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blueAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.school, color: Colors.blueAccent),
                  const SizedBox(width: 10),
                  Text(
                    "Total SKS yang telah diambil: $totalSKS SKS",
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Tombol kembali
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back),
              label: const Text("Kembali"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
