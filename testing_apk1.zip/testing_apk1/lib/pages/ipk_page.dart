import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class IPKPage extends StatelessWidget {
  const IPKPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Data IPK tiap semester
    final ipkData = [
      {'semester': 1, 'ipk': 4.00},
      {'semester': 2, 'ipk': 3.88},
      {'semester': 3, 'ipk': 3.90},
      {'semester': 4, 'ipk': 3.78},
      {'semester': 5, 'ipk': 3.75},
      {'semester': 6, 'ipk': 3.80},
      {'semester': 7, 'ipk': 3.85},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail IPK"),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Image.network('https://avatar.iran.liara.run/public/38', height: 100),
            const SizedBox(height: 10),
            const Text(
              "Indeks Prestasi Kumulatif (IPK)",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              "IPK adalah rata-rata nilai keseluruhan dari mata kuliah yang telah ditempuh mahasiswa.",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),

            // === 📈 DIAGRAM GARIS IPK ===
            Expanded(
              flex: 2,
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: LineChart(
                    LineChartData(
                      backgroundColor: Colors.white,
                      gridData: const FlGridData(show: true),
                      titlesData: FlTitlesData(
                        leftTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: true, reservedSize: 40),
                        ),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              if (value.toInt() < 1 || value.toInt() > 7) return const SizedBox();
                              return Text("S${value.toInt()}");
                            },
                          ),
                        ),
                      ),
                      borderData: FlBorderData(
                        show: true,
                        border: Border.all(color: Colors.blueAccent, width: 1),
                      ),
                      minY: 3.5,
                      maxY: 4.1,
                      lineBarsData: [
                        LineChartBarData(
                          isCurved: true,
                          color: Colors.blueAccent,
                          barWidth: 4,
                          belowBarData: BarAreaData(show: true, color: Colors.blueAccent.withOpacity(0.2)),
                          dotData: const FlDotData(show: true),
                          spots: ipkData
                              .map((data) => FlSpot(data['semester']!.toDouble(), data['ipk']!.toDouble()))
                              .toList(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),

            // === 📊 TABEL DATA IPK ===
            Expanded(
              flex: 1,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: DataTable(
                  headingRowColor: WidgetStateProperty.all(Colors.blueAccent.withOpacity(0.1)),
                  columns: const [
                    DataColumn(label: Text("Semester", style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text("IPK", style: TextStyle(fontWeight: FontWeight.bold))),
                  ],
                  rows: ipkData.map((data) {
                    return DataRow(
                      cells: [
                        DataCell(Text("Semester ${data['semester']}")),
                        DataCell(Text(
                          data['ipk'].toString(),
                          style: const TextStyle(
                            color: Colors.blueAccent,
                            fontWeight: FontWeight.bold,
                          ),
                        )),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Tombol kembali
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back),
              label: const Text("Kembali"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
