import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  final Map<String, String> mahasiswa = {
    "nama": "Suherman Anjasmoro",
    "nim": "231080300086",
    "jurusan": "Informatika",
    "foto": "https://avatar.iran.liara.run/public/38"
  };

  final List<Map<String, dynamic>> dataAkademik = [
    {"title": "IPK", "value": "3.85/4.00", "icon": Icons.school, "color": Colors.blue, "route": "/ipk"},
    {"title": "Total SKS", "value": "110", "icon": Icons.book, "color": Colors.green, "route": "/sks"},
    {"title": "Semester", "value": "7", "icon": Icons.calendar_today, "color": Colors.orange, "route": "/semester"},
    {"title": "Jadwal Kuliah", "value": "Lihat", "icon": Icons.schedule, "color": Colors.purple, "route": "/jadwal"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Dashboard Akademik"),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Profil Mahasiswa
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blueAccent,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage(mahasiswa["foto"]!),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(mahasiswa["nama"]!,
                            style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text("NIM: ${mahasiswa["nim"]}", style: const TextStyle(color: Colors.white70)),
                        Text(mahasiswa["jurusan"]!, style: const TextStyle(color: Colors.white70)),
                      ],
                    ),
                  )
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Grid Menu Akademik
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: dataAkademik.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.9,
              ),
              itemBuilder: (context, index) {
                final item = dataAkademik[index];
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        blurRadius: 6,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(item["icon"], color: item["color"], size: 40),
                        const SizedBox(height: 8),
                        Text(
                          item["title"],
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item["value"],
                          style: TextStyle(color: Colors.grey[700]),
                        ),
                        const SizedBox(height: 12),

                        // Tombol Lihat Detail
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () => Navigator.pushNamed(context, item["route"]),
                            icon: const Icon(Icons.arrow_forward_ios, size: 14),
                            label: const Text("Lihat Detail"),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blueAccent,
                              foregroundColor: Colors.white,
                              textStyle: const TextStyle(fontSize: 13),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
