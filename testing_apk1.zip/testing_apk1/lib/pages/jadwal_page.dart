import 'package:flutter/material.dart';

class JadwalPage extends StatelessWidget {
  const JadwalPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> jadwalKuliah = [
      {
        'hari': 'Senin',
        'matkul': 'Pemrograman Mobile',
        'ruang': 'Lab Komputer 1',
        'dosen': 'Dr. Andi Prasetyo, M.Kom'
      },
      {
        'hari': 'Selasa',
        'matkul': 'Kecerdasan Buatan',
        'ruang': 'Ruang 203',
        'dosen': 'Prof. Rina Kusuma, M.Sc'
      },
      {
        'hari': 'Rabu',
        'matkul': 'Manajemen Proyek TI',
        'ruang': 'Ruang 105',
        'dosen': 'Budi Santoso, M.Kom'
      },
      {
        'hari': 'Kamis',
        'matkul': 'Interaksi Manusia dan Komputer',
        'ruang': 'Ruang 204',
        'dosen': 'Dr. Siti Marlina, M.Kom'
      },
      {
        'hari': 'Jumat',
        'matkul': 'Keamanan Informasi',
        'ruang': 'Lab Komputer 2',
        'dosen': 'Eko Nugroho, M.Kom'
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Jadwal Kuliah"),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Header gambar
            Image.network(
              'https://cdn-icons-png.flaticon.com/512/3135/3135786.png',
              height: 90,
            ),
            const SizedBox(height: 12),

            const Text(
              "Jadwal Kuliah Mahasiswa",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              "Berikut adalah jadwal kuliah aktif semester ini beserta ruang, dosen, dan hari perkuliahan.",
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 20),

            // === TABEL YANG RAPAT & RAPI ===
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: DataTable(
                    headingRowColor: WidgetStateProperty.all(Colors.blueAccent.withOpacity(0.2)),
                    dataRowColor: WidgetStateProperty.resolveWith<Color?>(
                      (Set<WidgetState> states) {
                        // Warna bergantian (zebra style)
                        int index = states.contains(WidgetState.selected) ? 1 : 0;
                        return index.isEven
                            ? Colors.white
                            : Colors.blueAccent.withOpacity(0.05);
                      },
                    ),
                    dataRowHeight: 60, // tinggi baris agar lega
                    columnSpacing: 24, // jarak antar kolom
                    horizontalMargin: 20,
                    dividerThickness: 1,
                    border: TableBorder.all(color: Colors.grey.shade300, width: 1),
                    columns: const [
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("Hari", style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("Mata Kuliah", style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("Ruang", style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                      DataColumn(
                        label: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 8),
                          child: Text("Dosen Pengampu", style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                    rows: List.generate(jadwalKuliah.length, (index) {
                      final data = jadwalKuliah[index];
                      return DataRow(
                        color: WidgetStateProperty.all(
                          index.isEven
                              ? Colors.white
                              : Colors.blueAccent.withOpacity(0.05),
                        ),
                        cells: [
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['hari']!),
                          )),
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['matkul']!),
                          )),
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['ruang']!),
                          )),
                          DataCell(Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(data['dosen']!),
                          )),
                        ],
                      );
                    }),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blueAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.blueAccent),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      "Pastikan hadir tepat waktu sesuai jadwal di atas untuk menjaga keaktifan perkuliahan.",
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back),
              label: const Text("Kembali"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
