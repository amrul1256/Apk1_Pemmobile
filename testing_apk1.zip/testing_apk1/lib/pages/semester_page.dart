import 'package:flutter/material.dart';

class SemesterPage extends StatelessWidget {
  const SemesterPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Data mahasiswa
    const String nama = "Suherman Anjasmoro";
    const String nim = "231080300086";
    const int tahunMasuk = 2023;

    // Ambil bulan sekarang untuk menentukan semester ganjil/genap
    final int bulanSekarang = DateTime.now().month;
    final bool isGanjil = (bulanSekarang >= 8 && bulanSekarang <= 12) || (bulanSekarang == 1);
    final String jenisSemester = isGanjil ? "Ganjil" : "Genap";

    // Hitung tahun berjalan dan semester ke berapa
    final int tahunSekarang = DateTime.now().year;
    final int selisihTahun = tahunSekarang - tahunMasuk;
    // Asumsi: setiap tahun ada 2 semester
    final int semesterSekarang = (selisihTahun * 2) + (isGanjil ? 1 : 2);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Semester"),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Image.network(
              'https://avatar.iran.liara.run/public/38',
              height: 100,
            ),
            const SizedBox(height: 16),
            const Text(
              "Informasi Semester Mahasiswa",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              "Berikut adalah informasi akademik mengenai semester aktif mahasiswa.",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),

            // === INFO MAHASISWA ===
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blueAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Icon(Icons.person, color: Colors.blueAccent),
                      const SizedBox(width: 8),
                      Text(
                        "Nama: $nama",
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.badge, color: Colors.blueAccent),
                      const SizedBox(width: 8),
                      Text(
                        "NIM: $nim",
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.calendar_today, color: Colors.blueAccent),
                      const SizedBox(width: 8),
                      Text(
                        "Tahun Masuk: $tahunMasuk",
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // === INFO SEMESTER AKTIF ===
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.blueAccent, width: 1.5),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  )
                ],
              ),
              child: Column(
                children: [
                  const Icon(Icons.school, size: 48, color: Colors.blueAccent),
                  const SizedBox(height: 8),
                  Text(
                    "Semester Aktif: Semester $semesterSekarang",
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Periode: Semester $jenisSemester ${DateTime.now().year}",
                    style: TextStyle(
                        fontSize: 16,
                        color: isGanjil ? Colors.deepOrange : Colors.green,
                        fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    jenisSemester == "Ganjil"
                        ? "Perkuliahan dimulai pada bulan Agustus – Januari"
                        : "Perkuliahan dimulai pada bulan Februari – Juli",
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 14),
                  ),
                ],
              ),
            ),

            const Spacer(),

            // Tombol kembali
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back),
              label: const Text("Kembali"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
