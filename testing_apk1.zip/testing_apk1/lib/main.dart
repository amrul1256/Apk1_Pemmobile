import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'pages/dashboard_page.dart';
import 'pages/ipk_page.dart';
import 'pages/sks_page.dart';
import 'pages/semester_page.dart';
import 'pages/jadwal_page.dart';

void main() {
  runApp(DashboardAkademikApp());
}

class DashboardAkademikApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dashboard Akademik',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        textTheme: GoogleFonts.poppinsTextTheme(),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => DashboardPage(),
        '/ipk': (context) => IPKPage(),
        '/sks': (context) => SKSPage(),
        '/semester': (context) => SemesterPage(),
        '/jadwal': (context) => JadwalPage(),
      },
    );
  }
}
